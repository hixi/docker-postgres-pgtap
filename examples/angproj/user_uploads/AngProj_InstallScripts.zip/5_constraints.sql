ALTER TABLE Angestellter
ADD CONSTRAINT check_Salaer
   CHECK (Salaer between 1000 and 20000);
   
   
UPDATE angestellter SET salaer=30000 where persnr = 1100;
select * from angestellter WHERE persnr = 1100;

ALTER TABLE ProjektZuteilung
ADD CONSTRAINT check_Zeitanteil
   CHECK (Zeitanteil between 10 and 90);

UPDATE ProjektZuteilung SET Zeitanteil=99 where persnr = 1100;
select * from ProjektZuteilung WHERE persnr = 1100;